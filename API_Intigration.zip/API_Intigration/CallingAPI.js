var mongoose = require('mongoose');
var express = require('express');
var bodyParser = require('body-parser');
var route = require('./route')

mongoose.connect("mongodb+srv://Vrunda:V5107757@cluster0.8ril4yg.mongodb.net/?retryWrites=true&w=majority").then(()=>{
    console.log('Connected');

    app = express();
    app.use(bodyParser.urlencoded({ extended : false }));
    app.use(express.json());
    app.use('/api',route)

    app.listen(3000,()=>{   
        console.log("Server started at 3000");
    })
}).catch((err)=>{
    console.log(err);
})
