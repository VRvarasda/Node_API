var mongoose = require("mongoose");

var movie_Schema = mongoose.Schema({
    Name:String,
    Rating:Number
})
module.exports = mongoose.model("movies",movie_Schema)